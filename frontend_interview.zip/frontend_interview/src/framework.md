# 框架综述

||我们的选择|其他主流工具|解释| 
|-|-|-|-| 
|Web开发框架| Flask，用Python语言| 主流Python Web开发框架： Django| 
前端开发框架| Vue2， Vue3| React， Angular| 
|通信框架|Axios| jQuery, Fetch... 
|前端组件库|Element UI, Element UI Plus, Echarts| d3.js...etc| 