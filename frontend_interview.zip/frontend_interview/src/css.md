# CSS



**Q:** css样式的优先级？ 
**难度:**  &#x2B50;&#x2B50;
<details>
    <summary> <span style='font-weight:bold'>A:</span> </summary>


!important > 行内 > 内联 > 外链
id > class > 伪类(first-child/last-child等等) > 元素
后声明 > 先声明（后声明的样式会覆盖掉先声明的样式，与使用顺序无关）
</details>

